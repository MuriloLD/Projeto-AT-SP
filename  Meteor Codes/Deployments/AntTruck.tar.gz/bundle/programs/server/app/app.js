var require = meteorInstall({"Collections":{"collections.js":["meteor/mongo",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////
//                                                                                     //
// Collections/collections.js                                                          //
//                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////
                                                                                       //
module.export({SuperTruck_Messages:function(){return SuperTruck_Messages},SuperTruck_VarsDB:function(){return SuperTruck_VarsDB},AntTruck_Messages:function(){return AntTruck_Messages},AntTruck_VarsDB:function(){return AntTruck_VarsDB}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});
                                                                                       //
// initializing the collection, used from client and server                            //
var SuperTruck_Messages = new Mongo.Collection("SP_mqttMessages");                     // 4
var SuperTruck_VarsDB = new Mongo.Collection("SP_Vars");                               // 5
                                                                                       //
var AntTruck_Messages = new Mongo.Collection("AT_mqttMessages");                       // 7
var AntTruck_VarsDB = new Mongo.Collection("AT_Vars");                                 // 8
                                                                                       //
                                                                                       // 10
/////////////////////////////////////////////////////////////////////////////////////////

}]},"Routes":{"routes.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////
//                                                                                     //
// Routes/routes.js                                                                    //
//                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////
                                                                                       //
                                                                                       //
// SuperTruck Routes                                                                   //
                                                                                       //
FlowRouter.route('/', {                                                                // 4
	name: 'home',                                                                         // 5
	action: function action() {                                                           // 6
		BlazeLayout.render('MainLayout', { main: 'homeLayout' });                            // 7
	}                                                                                     // 8
});                                                                                    // 4
                                                                                       //
FlowRouter.route('/SP_odometria', {                                                    // 11
	name: 'odometria',                                                                    // 12
	action: function action() {                                                           // 13
		BlazeLayout.render('MainLayout', { main: 'SP_odometriaLayout' });                    // 14
	}                                                                                     // 15
});                                                                                    // 11
                                                                                       //
FlowRouter.route('/SP_velocidade', {                                                   // 18
	name: 'velocidade',                                                                   // 19
	action: function action() {                                                           // 20
		BlazeLayout.render('MainLayout', { main: 'SP_velocidadeLayout' });                   // 21
	}                                                                                     // 22
});                                                                                    // 18
                                                                                       //
FlowRouter.route('/SP_ultrassom', {                                                    // 25
	name: 'ultrassom',                                                                    // 26
	action: function action() {                                                           // 27
		BlazeLayout.render('MainLayout', { main: 'SP_ultrassomLayout' });                    // 28
	}                                                                                     // 29
});                                                                                    // 25
                                                                                       //
FlowRouter.route('/SP_teleop', {                                                       // 32
	name: 'teleop',                                                                       // 33
	action: function action() {                                                           // 34
		BlazeLayout.render('MainLayout', { main: 'SP_teleopLayout' });                       // 35
	}                                                                                     // 36
});                                                                                    // 32
                                                                                       //
FlowRouter.route('/SP_mqtt', {                                                         // 39
	name: 'mqtt',                                                                         // 40
	action: function action() {                                                           // 41
		BlazeLayout.render('MainLayout', { main: 'SP_mqttLayout' });                         // 42
	}                                                                                     // 43
});                                                                                    // 39
                                                                                       //
//////////////////////////////////////////////////////////////////////                 //
                                                                                       //
// AntTruck Routes                                                                     //
                                                                                       //
FlowRouter.route('/', {                                                                // 51
	name: 'home',                                                                         // 52
	action: function action() {                                                           // 53
		BlazeLayout.render('MainLayout', { main: 'homeLayout' });                            // 54
	}                                                                                     // 55
});                                                                                    // 51
                                                                                       //
FlowRouter.route('/AT_odometria', {                                                    // 58
	name: 'odometria',                                                                    // 59
	action: function action() {                                                           // 60
		BlazeLayout.render('MainLayout', { main: 'AT_odometriaLayout' });                    // 61
	}                                                                                     // 62
});                                                                                    // 58
                                                                                       //
FlowRouter.route('/AT_velocidade', {                                                   // 65
	name: 'velocidade',                                                                   // 66
	action: function action() {                                                           // 67
		BlazeLayout.render('MainLayout', { main: 'AT_velocidadeLayout' });                   // 68
	}                                                                                     // 69
});                                                                                    // 65
                                                                                       //
FlowRouter.route('/AT_ultrassom', {                                                    // 72
	name: 'ultrassom',                                                                    // 73
	action: function action() {                                                           // 74
		BlazeLayout.render('MainLayout', { main: 'AT_ultrassomLayout' });                    // 75
	}                                                                                     // 76
});                                                                                    // 72
                                                                                       //
FlowRouter.route('/AT_teleop', {                                                       // 79
	name: 'teleop',                                                                       // 80
	action: function action() {                                                           // 81
		BlazeLayout.render('MainLayout', { main: 'AT_teleopLayout' });                       // 82
	}                                                                                     // 83
});                                                                                    // 79
                                                                                       //
FlowRouter.route('/AT_mqtt', {                                                         // 86
	name: 'mqtt',                                                                         // 87
	action: function action() {                                                           // 88
		BlazeLayout.render('MainLayout', { main: 'AT_mqttLayout' });                         // 89
	}                                                                                     // 90
});                                                                                    // 86
                                                                                       //
//////////////////////////////////////////////////////////////////////                 //
/////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"methods.js":["meteor/meteor","../Collections/collections",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////
//                                                                                     //
// server/methods.js                                                                   //
//                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////
                                                                                       //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var SuperTruck_Messages;module.import('../Collections/collections',{"SuperTruck_Messages":function(v){SuperTruck_Messages=v}});var SuperTruck_VarsDB;module.import('../Collections/collections',{"SuperTruck_VarsDB":function(v){SuperTruck_VarsDB=v}});var AntTruck_Messages;module.import('../Collections/collections',{"AntTruck_Messages":function(v){AntTruck_Messages=v}});var AntTruck_VarsDB;module.import('../Collections/collections',{"AntTruck_VarsDB":function(v){AntTruck_VarsDB=v}});
                                                                                       //
                                                                                       // 3
                                                                                       // 4
                                                                                       //
                                                                                       // 6
                                                                                       // 7
                                                                                       //
// some methods called by the client                                                   //
Meteor.methods({                                                                       // 10
    // start receiving messages with the set topic-query                               //
    startClient: function startClient() {                                              // 12
        console.log("startClient called");                                             // 13
        mqttClient.subscribe(topicQuery);                                              // 14
    },                                                                                 // 15
    // stop receiving messages                                                         //
    stopClient: function stopClient() {                                                // 17
        console.log("stopClient called");                                              // 18
        mqttClient.unsubscribe(topicQuery);                                            // 19
    },                                                                                 // 20
    // set a new topic query, unsubscribe from the old and subscribe to the new one    //
    setTopicQuery: function setTopicQuery(newTopicQuery) {                             // 22
        console.log("set new Topic: " + newTopicQuery);                                // 23
        mqttClient.unsubscribe(topicQuery).subscribe(newTopicQuery);                   // 24
        topicQuery = newTopicQuery;                                                    // 25
    },                                                                                 // 26
    // send the topic query to the caller                                              //
    getTopicQuery: function getTopicQuery() {                                          // 28
        return topicQuery;                                                             // 29
    },                                                                                 // 30
    // publishes a message with a topic to the broker                                  //
    publishMessage: function publishMessage(topic, message) {                          // 32
        // console.log("message to send: " + topic + ": " + message);                  //
        mqttClient.publish(topic, message, function () {                               // 34
            // console.log("message sent: " + message);                                //
        });                                                                            // 36
    },                                                                                 // 37
    getConfigValues: function getConfigValues() {                                      // 38
        return config;                                                                 // 39
    },                                                                                 // 40
    SP_cleanDB: function SP_cleanDB() {                                                // 41
        SuperTruck_Messages.remove({});                                                // 42
        SuperTruck_VarsDB.remove({});                                                  // 43
    },                                                                                 // 44
    AT_cleanDB: function AT_cleanDB() {                                                // 45
        AntTruck_Messages.remove({});                                                  // 46
        AntTruck_VarsDB.remove({});                                                    // 47
    }                                                                                  // 48
});                                                                                    // 10
                                                                                       //
// for development purposes, delete the DB on startup, don't collect too much old data
// Meteor.startup(function () {                                                        //
//     Messages.remove({});                                                            //
// });                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////

}],"mqttClient.js":["meteor/meteor","../Collections/collections","mqtt",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////
//                                                                                     //
// server/mqttClient.js                                                                //
//                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////
                                                                                       //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var SuperTruck_Messages;module.import('../Collections/collections',{"SuperTruck_Messages":function(v){SuperTruck_Messages=v}});var SuperTruck_VarsDB;module.import('../Collections/collections',{"SuperTruck_VarsDB":function(v){SuperTruck_VarsDB=v}});var AntTruck_Messages;module.import('../Collections/collections',{"AntTruck_Messages":function(v){AntTruck_Messages=v}});var AntTruck_VarsDB;module.import('../Collections/collections',{"AntTruck_VarsDB":function(v){AntTruck_VarsDB=v}});
                                                                                       //
                                                                                       // 3
                                                                                       // 4
                                                                                       //
                                                                                       // 6
                                                                                       // 7
                                                                                       //
var mqtt = require('mqtt');                                                            // 9
                                                                                       //
// All messages at topic: SuperTruck/#                                                 //
mqttClient = mqtt.connect('mqtt://localhost', {                                        // 12
    port: 1883,                                                                        // 13
    clientId: 'Meteor Server',                                                         // 14
    username: 'ispace',                                                                // 15
    password: 'ispace'                                                                 // 16
});                                                                                    // 12
                                                                                       //
mqttClient.on('connect', function () {                                                 // 20
    mqttClient.subscribe('SuperTruck/#');                                              // 21
    mqttClient.subscribe('AntTruck/#');                                                // 22
    mqttClient.publish('SuperTruck/Server', 'Meteor Connected!');                      // 23
});                                                                                    // 24
                                                                                       //
mqttClient.on('message', function (topic, message) {                                   // 26
    // console.log('topic: '+topic+' message: '+message);                              //
                                                                                       //
    if (topic.toString().startsWith('SuperTruck/Vars')) {                              // 29
        insertMessage(topic, message, SuperTruck_VarsDB);                              // 30
    } else if (topic.toString().startsWith('AntTruck/Vars')) {                         // 31
        insertMessage(topic, message, AntTruck_VarsDB);                                // 33
    } else if (topic.toString().startsWith('SuperTruck/')) {                           // 34
        insertMessage(topic, message, SuperTruck_Messages);                            // 36
    } else if (topic.toString().startsWith('AntTruck/')) {                             // 37
        insertMessage(topic, message, AntTruck_Messages);                              // 39
    }                                                                                  // 40
});                                                                                    // 41
/////////////////////////////////////////////////////////////////                      //
                                                                                       //
// msg vars must be included in a Meteor Fiber:                                        //
var insertMessage = Meteor.bindEnvironment(function (topic, message, DataBase) {       // 45
    DataBase.insert({                                                                  // 46
        _topic: topic,                                                                 // 47
        _message: message.toString(),                                                  // 48
        _date: new Date()                                                              // 49
    });                                                                                // 46
});                                                                                    // 51
/////////////////////////////////////////////////////////////////////////////////////////

}],"main.js":["meteor/meteor","../Collections/collections",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////
//                                                                                     //
// server/main.js                                                                      //
//                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////
                                                                                       //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Messages;module.import('../Collections/collections',{"default":function(v){Messages=v}});
                                                                                       //
                                                                                       // 3
                                                                                       //
Meteor.startup(function () {                                                           // 5
  // code to run on server at startup                                                  //
});                                                                                    // 7
/////////////////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json"]});
require("./Collections/collections.js");
require("./Routes/routes.js");
require("./server/methods.js");
require("./server/mqttClient.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map
