/* 
 *
 * 	Lib to write 16 and 32 bits variables in packages of Bytes.
 * 
 *Improvemets to do:
 *	[ ] - Dynamically allocate memory for the buffer.	
 */

#ifndef Serialize_h
#define Serialize_h

#include "Arduino.h"

class Serializer
{
public:
  //Methods:
  // Serializer();
  // void add (void* ptr, int size);
  // uint8_t getCount();
  // char getBufferIndex(int i);
  // void clean();
  Serializer(){
     count = 0;
  }

  bool push_back(char c) { //Adds each byte into the private buffer
    if (count < 150) {
      buffer[count] = c;
      count++;
        return true;
    }else {
      return false;
    }
  }

  void add(void* ptr, int size) {
    char* ptr2 = (char*)ptr + (size-1);
    while (size--) {
      this->push_back(*(ptr2));
      --ptr2;
    }
  }
    

  char getBufferIndex(int i){
    return this->buffer[i];
  }


  void clean(){
    for(int j=0; j<=count; j++){
      this->buffer[j] = NULL;
    }
    count = 0;
  }

    
  uint8_t getCount(){
    return count;
  }
    
  private:
    char buffer[150];
    uint8_t count;
};



#endif