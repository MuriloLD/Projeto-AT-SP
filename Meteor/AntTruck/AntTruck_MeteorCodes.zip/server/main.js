import { Meteor } from 'meteor/meteor';

import Messages from '../Collections/collections'

Meteor.startup(() => {
  // code to run on server at startup
});
